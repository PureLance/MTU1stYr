FERRY_PRICE = 599
PASSENGER_PRICE = 90

Name = input("What is the drivers name? ")
Passenger = int(input("How many passengers are there? "))

Total_Cost = FERRY_PRICE + (Passenger*PASSENGER_PRICE)
Discount = Total_Cost*0.12
Cost_Discount = Total_Cost - Discount

print("="*45)
print(f"{Name}")
print(f"The total cost of the ride is €{Total_Cost}")
print(f"With the discount, the total cost is calculated to be €{Cost_Discount}")
print("="*45)

