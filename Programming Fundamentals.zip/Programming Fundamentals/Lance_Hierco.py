#AUTHOR LANCE
#Description: To create a program that helps organise the Blackwater Annual Concert

print('\u2501'*60)
print(f"\t\tWelcome to the Blackwater Annual Concert!")
print('\u2501'*60)
print("Black water Annual Menu")

#Add fixed variables here
dancer = 0
singer = 0
musician = 0
total_time = 0
menu_choice = 0
counter = 0
longest_time = 0
option_two_counter = 0


while menu_choice !=3:
    menu_choice = int(input("Enter the program you wish to go to.\n"
                          "1. Performers\n"
                          "2. Generate Concert Details\n"
                          "3. Exit\n"))
    if menu_choice == 1:
        number_of_performers = int(input("How many performers are you adding?\n>"))
        for i in range(number_of_performers):
            newfile = open("performers.txt","a")
            booking = print(f"Booking: {counter +1} / {number_of_performers}")
            counter +=1
            performers_firstname = input("Enter the first name of the Performer\n>")
            performers_surname = input(("Enter the surname of the Performer\n>"))
            performance_choice = int(input("Type of Performance:\n"
                                           "1. Musical\n"
                                           "2. Singer\n"
                                           "3. Dance\n"))
            timeslot = int(input("Time slot required? (minutes)"))
            #If statements for each choice
            if performance_choice == 1:
                performance_name = "Musician"
                print(f" {performers_firstname} {performers_surname}  {performance_name} {timeslot}", file=newfile)
                musician = musician +1
                total_time += timeslot
                if longest_time < timeslot:
                    longest_time = timeslot
                    longest_info = f"The longest act is {performers_firstname} {performers_surname} with {timeslot} minutes"

            elif performance_choice== 2:
                performance_name = "Singer"
                print(f" {performers_firstname} {performers_surname}  {performance_name} {timeslot}", file=newfile)
                singer = singer + 1
                total_time += timeslot
                if longest_time < timeslot:
                    longest_time = timeslot
                    longest_info = f"The longest act is {performers_firstname} {performers_surname} with {timeslot} minutes"
            elif performance_choice == 3:
                performance_name = "Dancer"
                print(f" {performers_firstname} {performers_surname}  {performance_name} {timeslot}", file=newfile)
                dancer = dancer + 1
                total_time += timeslot
                if longest_time < timeslot:
                    longest_time = timeslot
                    longest_info = f"The longest act is {performers_firstname} {performers_surname} with {timeslot} minutes"
                newfile.close()

        #End summary notes before loop
        print("Summary Notes:")
        print('\u2501' * 30)
        print(f"{musician} Musicians")
        print(f"{singer} singers")
        print(f"{dancer} dancers")
        print(longest_info)
        hours = total_time / 60
        mins = total_time % 60
        print(f" Total time required: {hours:.0f} hr(s) and {mins} minute(s)")
        print('\u2501' * 30)
    #Generate list
    elif menu_choice == 2:
        newfile = open("performers.txt","r")

        try:
            connection = open("performers.txt", "r")
            for line in connection:
                line_as_a_list = line.split()
                firstname = line_as_a_list[0]
                surname = line_as_a_list[1]
                performance = line_as_a_list[2]
                TIMESLOT = int(line_as_a_list[3])
                if TIMESLOT > 15:
                    print(f"{option_two_counter+1}:{firstname} {surname}*\t({performance})\t{TIMESLOT} minutes ")
                    option_two_counter +=1
                else:
                    print(f"{option_two_counter+1}:{firstname} {surname}\t({performance})\t{TIMESLOT} minutes ")
                    option_two_counter +=1
            connection.close()
        except FileNotFoundError:
            print("The file performers.txt could not be found")
        except IndexError:
            print("Error, your code may be out of range.")

    elif menu_choice == 3:
        print("Thank you, Goodbye")



