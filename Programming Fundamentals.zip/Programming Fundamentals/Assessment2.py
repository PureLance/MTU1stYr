#@Author: Lance Hierco
#Description: To specify the car and, read the car's tyre pressure from the user, and displays an output depending on their tyre pressure.

car_type = input("Please enter your car type. >").lower()
#Ask for cars type.
if car_type =='nissan leaf':
    psi_pressure = int(input("Enter the Pressure PSI of your tyre. >"))
    # Car type PSI is less than or equal to 41, or car type is greater or equal to 39.
    if psi_pressure <= 41 and psi_pressure >= 39:
        print(f"Your {car_type}'s tyre pressure is just right! At {psi_pressure }PSI.")
    # Car type PSI is greater than 41.
    elif psi_pressure >41:
        print(f"Your {car_type}'s tyre pressure is too high, at {psi_pressure} PSI. \nRelease the pressure to at least 41 PSI.")
    # Car type PSI is less than 39
    else:
        print(f"Your {car_type}'s tyre pressure is too low, at {psi_pressure} PSI. \nPump up the pressure to at least 39 PSI.")


if car_type =='nissan qashqai':
    psi_pressure = int(input("Enter the Pressure PSI of your tyre. >"))
    # Car type PSI is less than or equal to 38, or car type is greater or equal to 36.
    if psi_pressure <= 38 and psi_pressure >= 36:
        print(f"Your {car_type}'s tyre pressure is just right! At {psi_pressure} PSI.")
    # Car type PSI is greater than 38.
    elif psi_pressure > 38:
        print(f"Your {car_type}'s tyre pressure is too high, at {psi_pressure} PSI. \nRelease the pressure to at least 38 PSI.")
    # Car type PSI is less than 39
    else:
        print(f"Your {car_type}'s tyre pressure is too low, at {psi_pressure} PSI. \nPump up the pressure to at least 36 PSI.")
